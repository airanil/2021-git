import { TestBed } from '@angular/core/testing';

import { PtjasLibService } from './ptjas-lib.service';

describe('PtjasLibService', () => {
  let service: PtjasLibService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PtjasLibService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
