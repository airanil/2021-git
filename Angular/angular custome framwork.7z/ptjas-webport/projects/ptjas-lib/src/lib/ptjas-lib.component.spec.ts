import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtjasLibComponent } from './ptjas-lib.component';

describe('PtjasLibComponent', () => {
  let component: PtjasLibComponent;
  let fixture: ComponentFixture<PtjasLibComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtjasLibComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtjasLibComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
