import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-ptjas-lib',
  template: `
    <p>
      ptjas-lib works!
    </p>
  `,
  styles: [
  ]
})
export class PtjasLibComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
