import { NgModule } from '@angular/core';
import { PtjasLibComponent } from './ptjas-lib.component';



@NgModule({
  declarations: [PtjasLibComponent],
  imports: [
  ],
  exports: [PtjasLibComponent]
})
export class PtjasLibModule { }
