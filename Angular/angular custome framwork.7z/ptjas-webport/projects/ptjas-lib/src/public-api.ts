/*
 * Public API Surface of ptjas-lib
 */

export * from './lib/ptjas-lib.service';
export * from './lib/ptjas-lib.component';
export * from './lib/ptjas-lib.module';
