import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './util/auth/auth.guard';

const routes: Routes = [
   { path: 'home', component: HomeComponent },
  // { path: 'tracking', component: TrackingComponent },
  // { path: 'chargesInquey', component: ChargesInqueryComponent },
  { path: 'back-office', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule), canActivate: [AuthGuard] },
  { path: 'agent', loadChildren: () => import('./agent/agent.module').then(m => m.AgentModule), canActivate: [AuthGuard] },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', redirectTo: '/home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
