import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from '../environments/environment';
import { Webtrack } from './model/Webtrack-model';
import { BaseResponse } from './util/model/base-response';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  public resultSet: BehaviorSubject<any> = new BehaviorSubject<any>([]);
  public preResultSet: BehaviorSubject<any> = new BehaviorSubject<any>([]);
  public localData: BehaviorSubject<any> = new BehaviorSubject<any>([]);

  constructor(private httpClient: HttpClient) { }


  getCgblInquey(data): Observable<BaseResponse<Webtrack>> {
    return this.httpClient.post<BaseResponse<Webtrack>>(`${environment.api('webtrack')}/cgblInquery`, data);
  }

  getWebTrackDetail(data): Observable<BaseResponse<Webtrack>> {
    return this.httpClient.post<BaseResponse<Webtrack>>(`${environment.api('webtrack')}`, data);
  }

  setLocalData(data) {
    this.localData.next(data);
  }
  getLocalData() {
    return this.localData;
  }
  setResult(data) {
    this.resultSet.next(data);
  }
  getResult() {
    return this.resultSet;
  }
  setPreResult(data) {
    this.preResultSet.next(data);
  }
  getPreResult() {
    return this.preResultSet;
  }
}
