export class ChargesInfo {
  id: string;
  codDes: string;
  amtBalIdr: string;

}
