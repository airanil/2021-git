import { ChargesInfo } from './ChargesInfo-model';
import { WebtrackDetail } from './WebtrackDetail-model';

export class Webtrack {
  id: number;
  awbPfx: string;
  awbNum: string;
  hawb: string;
  expDate: string;
  expTime: string;
  origin: string;
  dest: string;
  qty: string;
  pcs: string;
  wgt: string;
  cgblWgt: string;
  arvlDate: string;
  shc: string;
  detail: WebtrackDetail[];
  chagesInfo: ChargesInfo[];
  total: string;
}
