export class WebtrackDetail {
  id: number;
  item: string;
  status: string;
  fsu: string;
}
