import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  @Output() editorClose = new EventEmitter<boolean>();
  loginForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['test'],
      password: ['test'],
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
     // this.authService.authenticate(this.loginForm.value, () => {
       // this.router.navigateByUrl('/agent/tracking');
        this.editorClose.emit(false);
    //  });
    }
  }
}
