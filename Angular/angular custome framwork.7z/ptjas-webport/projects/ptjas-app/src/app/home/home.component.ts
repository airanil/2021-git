import { AfterContentInit, Output } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AppService } from '../app.service';
import { Webtrack } from '../model/Webtrack-model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterContentInit {

  editorOpened = false;

  dataSource: any = [{
    ID: 2,
    awb: '5465464',
    origin: 'Premier Buy',
    destination: '7601 Penn Avenue South',
    quality: 'Richfield',
    weight: 'Minnesota',
    shc: 55423,
    detail: [{
      id: 1,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    },
    {
      id: 2,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    },
    {
      id: 3,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    }]

  }];

  showFiller = false;
  webtrackForm: FormGroup;
  constructor(private router: Router, private appService: AppService, private formBuilder: FormBuilder) { }

  ngAfterContentInit(): void {
  }

  onSearch() {

    let webtrack: Webtrack = new Webtrack();
    webtrack = this.webtrackForm.value;

    if (this.webtrackForm.valid) {
      this.appService.getWebTrackDetail(webtrack).subscribe(data => {
        console.log(data);
        this.appService.setResult(data);
        this.appService.setPreResult(data);
        this.router.navigate(['/agent/cargoList']);
      });
    }
  }

  editorClose(val) {
    console.log(val);
    this.editorOpened = val;
  }

  ngOnInit(): void {

    this.webtrackForm = this.formBuilder.group({
      awbPfx: '',
      awbNum: '',
      hawb: ''
    });
    // console.log("check");
    // this.editorOpened = false;
  }

}
