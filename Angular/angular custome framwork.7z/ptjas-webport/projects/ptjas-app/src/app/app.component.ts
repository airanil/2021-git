import { Component } from '@angular/core';

@Component({
  selector: 'app-root,ptjas-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  // title = 'ptjas-app';
}
