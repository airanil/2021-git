import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiTrackingComponent } from './multi-tracking.component';

describe('MultiTrackingComponent', () => {
  let component: MultiTrackingComponent;
  let fixture: ComponentFixture<MultiTrackingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiTrackingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
