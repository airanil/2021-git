import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UtilModule } from '../util/util.module';
import { AgentRoutingModule } from './agent-routing.module';
import { ChargesInqueryComponent } from './charges-inquery/charges-inquery.component';
import { CargoTrackingComponent } from './cargo-tracking/cargo-tracking.component';
import { MultiTrackingComponent } from './multi-tracking/multi-tracking.component';



@NgModule({
  declarations: [
  ChargesInqueryComponent,
  CargoTrackingComponent,
  MultiTrackingComponent,

],
  imports: [
    CommonModule,
    // CommonImportModule,
    AgentRoutingModule,
    UtilModule
  ]
})
export class AgentModule { }
