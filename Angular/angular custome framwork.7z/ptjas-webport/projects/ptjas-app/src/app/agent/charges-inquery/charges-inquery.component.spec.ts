import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargesInqueryComponent } from './charges-inquery.component';

describe('ChargesInqueryComponent', () => {
  let component: ChargesInqueryComponent;
  let fixture: ComponentFixture<ChargesInqueryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChargesInqueryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChargesInqueryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
