import { HostListener } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AppService } from '../../app.service';
import { Webtrack } from '../../model/Webtrack-model';

@Component({
  selector: 'app-charges-inquery',
  templateUrl: './charges-inquery.component.html',
  styleUrls: ['./charges-inquery.component.scss']
})
export class ChargesInqueryComponent implements OnInit {

  isMapped = true;
  dataSource: Webtrack[] = [];
  localData: any;
  backedData: any;

  cgrblForm: FormGroup;
  constructor(private appService: AppService, private formBuilder: FormBuilder) { }
  onQuery() {
    //   this.isMapped = !this.isMapped;
    let webtrack: Webtrack = new Webtrack();
    webtrack = this.cgrblForm.value;
    if (this.cgrblForm.valid) {
      this.appService.getCgblInquey(webtrack).subscribe(result => {
        this.appService.setResult(result);
        this.appService.resultSet.subscribe((getResult) => {
          this.isMapped = true;
          this.dataSource[0] = getResult.data;
        });

      });
    }

  }

  @HostListener('window:popstate', ['$event'])
  onPopState(event) {
    this.appService.preResultSet.subscribe((backedData) => {
      this.appService.setResult(backedData);
    });
    console.log('Back button pressed');
  }

  ngOnInit(): void {
    //  this.dataSource = this.appService.getData(); // this.route.snapshot.paramMap.get('obj');
    // this.appService.setData(this.dataSource);
    this.appService.localData.subscribe((data) => {
      console.log(data);
      this.localData = data;
      if (data !== []) {
        this.cgrblForm = this.formBuilder.group({
          awbPfx: [data.awbPfx],
          awbNum: [data.awbNum],
          hawb: [data.hawb],
          expDate: [data.expDate],
          expTime: [data.expTime]
        });
      }
      else {
        this.cgrblForm = this.formBuilder.group({
          awbPfx: [''],
          awbNum: [''],
          hawb: [''],
          expDate: [''],
          expTime: ['']
        });
      }

      this.onQuery();
    });
  }


}
