import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CargoTrackingComponent } from './cargo-tracking/cargo-tracking.component';
import { ChargesInqueryComponent } from './charges-inquery/charges-inquery.component';
import { MultiTrackingComponent } from './multi-tracking/multi-tracking.component';

const routes: Routes = [
  { path: 'tracking', component: MultiTrackingComponent },
  { path: 'cargoList', component: CargoTrackingComponent },
  { path: 'chargesInquey', component: ChargesInqueryComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgentRoutingModule { }
