import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../app.service';

@Component({
  selector: 'app-multi-tracking',
  templateUrl: './multi-tracking.component.html',
  styleUrls: ['./multi-tracking.component.scss']
})
export class MultiTrackingComponent implements OnInit {
  isEmpty: boolean = false;
  airwaybills = [{
    id: "7478654654653",
    region: 'North America',
    country: 'USA',
    city: 'New York',
    amount: 5220,
    date: '2006/01/05'
  }, {
    id: "7478654654654",
    region: 'North America',
    country: 'USA',
    city: 'Los Angeles',
    amount: 4225,
    date: '2006/01/06'
  }, {
    id: "7478654654655",
    region: 'North America',
    country: 'USA',
    city: 'Denver',
    amount: 4260,
    date: '2006/01/03'
  }, {
    id: "7478654654656",
    region: 'North America',
    country: 'CAN',
    city: 'Vancouver',
    amount: 1860,
    date: '2006/01/14'
  }, {
    id: "7478654654657",
    region: 'North America',
    country: 'CAN',
    city: 'Edmonton',
    amount: 1490,
    date: '2006/01/03'
  }, {
    id: "7478654654658",
    region: 'South America',
    country: 'BRA',
    city: 'Rio de Janeiro',
    amount: 580,
    date: '2006/01/04'
  }, {
    id: "7478654654659",
    region: 'South America',
    country: 'ARG',
    city: 'Buenos Aires',
    amount: 495,
    date: '2006/01/16'
  }];

  airwaybill = {
    id: "7478654654610",
    region: 'South America',
    country: 'ARG',
    city: 'Buenos Aires',
    amount: 495,
    date: '2006/01/16'
  };

  dataSource: any = [{
    ID: 1,
    awb: '5465464',
    origin: 'Premier Buy',
    destination: '7601 Penn Avenue South',
    quality: 'Richfield',
    weight: 'Minnesota',
    shc: 55423,
    detail: [{
      id: 0,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    },
    {
      id: 1,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    },
    {
      id: 2,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    }]

  }, {
    ID: 2,
    awb: '5465464',
    origin: 'Premier Buy',
    destination: '7601 Penn Avenue South',
    quality: 'Richfield',
    weight: 'Minnesota',
    shc: 55423,
    detail: [{
      id: 4,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    },
    {
      id: 5,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    },
    {
      id: 6,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    }]

  },
  {
    ID: 3,
    awb: '5465464',
    origin: 'Premier Buy',
    destination: '7601 Penn Avenue South',
    quality: 'Richfield',
    weight: 'Minnesota',
    shc: 55423,
    detail: [{
      id: 6,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    },
    {
      id: 7,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    },
    {
      id: 8,
      item: 'Prepare 2013 Financial',
      status: '2013/01/15',
      fsu: '2013/01/31'
    }]

  }];

  constructor(private router: Router, private appService: AppService) {
  }

  track() {
    this.isEmpty = !this.isEmpty;
    this.appService.setResult(this.dataSource);
    this.router.navigate(['/agent/cargoList']);
  }

  ngOnInit(): void {
  }
}
