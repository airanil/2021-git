import { EventEmitter, Output } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../../app.service';
import { Webtrack } from '../../model/Webtrack-model';

@Component({
  selector: 'app-cargo-tracking',
  templateUrl: './cargo-tracking.component.html',
  styleUrls: ['./cargo-tracking.component.scss']
})
export class CargoTrackingComponent implements OnInit {

  editorOpened = false;
  dataSource: Webtrack[] = [];
  breakPoint = false;

  constructor(private router: Router, private route: ActivatedRoute, private appService: AppService) { }

  ngOnInit(): void {
    //  this.dataSource = this.appService.getData(); // this.route.snapshot.paramMap.get('obj');

    this.appService.resultSet.subscribe((data) => {
      if (!this.breakPoint && data?.data !== []) {
        this.dataSource.push(data.data);
        this.breakPoint = true;
      }
    });

  }

  checkInquery(rowData) {
    console.log(rowData.data);
    this.appService.setLocalData(rowData.data);
    this.router.navigate(['/agent/chargesInquey']);

  }

  editorClose(val) {
    console.log(val);
    this.editorOpened = val;
  }


}
