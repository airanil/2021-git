import { BaseMessage } from './base-message';

describe('BaseMessage', () => {
  it('should create an instance', () => {
    expect(new BaseMessage()).toBeTruthy();
  });
});
