import { BaseModel } from './base-model';

describe('BaseModel', () => {
  it('should create an instance', () => {
    expect(new BaseModel()).toBeTruthy();
  });
});
