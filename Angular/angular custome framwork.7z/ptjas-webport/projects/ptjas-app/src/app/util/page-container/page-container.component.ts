import { Portal } from '@angular/cdk/portal';
import { Input } from '@angular/core';
import { AfterContentInit, Component, ContentChild, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'app-page-container,page-container',
  templateUrl: './page-container.component.html',
  styleUrls: ['./page-container.component.scss'],
})
export class PageContainerComponent implements OnInit, AfterContentInit {

  @Input() editorOpen = false;

  loginAsAgent = true;
  selectedValue = 'KNO';
  airports: {} = [
    {value: 'CGK', viewValue: 'CGK'},
    {value: 'HLP', viewValue: 'HLP'},
    {value: 'KJT', viewValue: 'KJT'},
    {value: 'KNO', viewValue: 'KNO'},
    {value: 'SUB', viewValue: 'SUB'},
    {value: 'DPS', viewValue: 'DPS'}
  ];
  constructor(private router: Router) { }

  @ContentChild('content', { static: true }) content: Portal<any>;
  @ContentChild('agentLogin', { static: true }) agentLogin: Portal<any>;
  @ContentChild('adminLogin', { static: true }) adminLogin: Portal<any>;
  ngAfterContentInit(): void {
  }

  ngOnInit(): void {
  }
  navigate(value) {
    this.loginAsAgent = (value === 'Agent') ? true : false;
    this.editorOpen = true;
  }

  onEditClose(val){
    this.editorOpen = !this.editorOpen;
  }
}
