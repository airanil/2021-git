import { BaseMessage } from './base-message';

export class FieldErrorMessage extends BaseMessage {
  fieldId: string;

  constructor(fieldId?: string, code?: string, type?: string, message?: string) {
    super(code, type, message)
    this.fieldId = fieldId;
  }
}
