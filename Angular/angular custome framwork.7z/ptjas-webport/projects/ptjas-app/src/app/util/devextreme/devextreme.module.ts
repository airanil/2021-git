import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DxDataGridModule, DxTooltipModule, DxButtonModule, DxPopupModule, DxTreeListModule } from 'devextreme-angular';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  exports: [
    DxDataGridModule,
    DxTooltipModule,
    DxButtonModule,
    DxPopupModule,
    DxTreeListModule]
})
export class DevextremeModule { }
