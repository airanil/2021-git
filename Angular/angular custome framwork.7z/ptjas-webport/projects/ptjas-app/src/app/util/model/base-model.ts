export class BaseModel {
  version: number;
}
