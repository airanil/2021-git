import { BaseResponse } from './base-response';

describe('BaseResponse', () => {
  it('should create an instance', () => {
    expect(new BaseResponse()).toBeTruthy();
  });
});
