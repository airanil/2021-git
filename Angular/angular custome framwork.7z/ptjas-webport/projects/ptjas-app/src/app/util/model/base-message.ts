export class BaseMessage {
  code: string;
  type: string;
  message: string;

  constructor(code?: string, type?: string, message?: string) {
    this.code = code;
    this.type = type;
    this.message = message;
  }
}
