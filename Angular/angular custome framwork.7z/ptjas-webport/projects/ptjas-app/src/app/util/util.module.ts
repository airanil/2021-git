import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexModule } from '@angular/flex-layout';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from '../login/login.component';
import { AuthModule } from './auth/auth.module';
import { CommonImportModule } from './common-import/common-import.module';
import { DevextremeModule } from './devextreme/devextreme.module';
import { MaterialModule } from './material/material.module';
import { BaseMessage } from './model/base-message';
import { PageContainerComponent } from './page-container/page-container.component';



@NgModule({
  declarations: [
    PageContainerComponent,
    LoginComponent
  ],
  imports: [
    CommonModule,
    CommonImportModule,
    MaterialModule,
    FlexModule,
    DevextremeModule,
    AuthModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  exports: [
    PageContainerComponent,
    CommonImportModule,
    MaterialModule,
    FlexModule,
    DevextremeModule,
    AuthModule,
    LoginComponent,
    FormsModule,
    ReactiveFormsModule,
  ]
})
export class UtilModule { }
