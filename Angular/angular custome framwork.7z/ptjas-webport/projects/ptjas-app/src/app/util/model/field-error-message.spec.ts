import { FieldErrorMessage } from './field-error-message';

describe('FieldErrorMessage', () => {
  it('should create an instance', () => {
    expect(new FieldErrorMessage()).toBeTruthy();
  });
});
