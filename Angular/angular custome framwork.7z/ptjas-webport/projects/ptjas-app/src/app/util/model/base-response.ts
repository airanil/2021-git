import { BaseMessage } from './base-message';

export class BaseResponse<T> {
  data: T;
  success: boolean;
  messages: BaseMessage[];

  constructor(data?: T, success?: boolean, messages?: BaseMessage[]) {
    this.data = data;
    this.success = success;
    this.messages = messages;
  }
}
