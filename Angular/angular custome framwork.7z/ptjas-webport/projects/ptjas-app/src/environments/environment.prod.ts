export const environment = {
  production: true,

  baseHref: '/ptjas',

  apis: {
    user: '/user',
    logout: '/logout',
    masters: '/api/masters',
    webtrack: '/api/webtrack',
  },

  api(api: string): string {
    return this.baseHref + this.apis[api];
  }
};
