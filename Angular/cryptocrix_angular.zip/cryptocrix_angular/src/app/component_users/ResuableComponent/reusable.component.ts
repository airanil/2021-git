import { Component } from "@angular/core";

@Component({
    selector : 'dashboard-body',
    templateUrl: './reusable.component.html',
    styleUrls:['./reusable.component.css']
})

export class DashboardResuableComponent{
    username:string;
    constructor(){
        this.username=localStorage.getItem("username");
    }
    logout(){
        localStorage.setItem('username',"");
    }

}