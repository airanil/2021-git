import {Component,OnInit,OnDestroy} from '@angular/core';
import { UserSerivce } from '../../services/user_service';
import {Router} from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder, AbstractControl } from '@angular/forms';


@Component({
    templateUrl:'./registration.component.html',
    providers:[UserSerivce],
    styleUrls:['./registration.component.css']
})
export class RegistrationComponent implements OnInit,OnDestroy{
    result:any;
    sign_up_error_msg:string="";
    show_sign_up_error:boolean=false;

    show_username_error:boolean;
    username_error_msg:string="username already exist";
    show_email_error:boolean;
    email_error_msg:"email already exist";
    button_disable:boolean=false;

    formGroupReg:FormGroup;

    constructor(private user_service:UserSerivce,private router:Router,private fb:FormBuilder){
    }
    ngOnInit(){
        //this.formGroupReg.controls['buy_amount'].value;
        this.formGroupReg=this.fb.group({
            username:['',Validators.required],
            email:['',Validators.compose([Validators.required])],
            password:['',Validators.compose([Validators.required,Validators.minLength(6)])],
            conf_password:['',Validators.compose([Validators.required])]
        });                      
        //this.formGroupReg.controls['password'].value
        
    }
    ngOnDestroy(){
    }   
    showError(data){
        console.log(data);       
    } 
    saveReg(regForm){           
            this.button_disable=true;
            this.sign_up_error_msg="please wait..";
            this.user_service.newUserEntry(regForm).subscribe(data=>{
                this.result=data;
                console.log(data['status']);
                if(this.result['status']==-1){                    
                    this.show_username_error=true;
                    this.formGroupReg.get('username').reset();
                    this.button_disable=false;
                }
                else if(this.result['status']==-2){                    
                    this.show_email_error=true
                    this.formGroupReg.get('email').reset();
                    this.button_disable=false;
                }
                else{
                    this.router.navigate(['/login']);
                }
            });
        }    

}//class
