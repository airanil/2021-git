import {Component,OnInit} from '@angular/core';
import {FormBuilder,FormGroup,Validators, FormControl,NgForm} from '@angular/forms'
import { from, timer, of } from 'rxjs';
import { UserSerivce } from 'src/app/services/user_service';
import { TimeInterval } from 'rxjs/internal/operators/timeInterval';
import {Observable} from 'rxjs';
import { takeUntil, switchMap, catchError } from 'rxjs/operators';
@Component({
    selector:'app-dashboard',
    templateUrl:'./app.dashboard.html',
    styleUrls:['./app.dashboard.css'],
    providers:[UserSerivce]


})
export class DashboardComponent implements OnInit {

    userName:string;
    buy_amount:string;
    buy_price:string;

    sell_amount:string;
    sell_price:string='';
    reactiveForm: FormGroup;
    formGroupBuy: FormGroup;

    coinData: any[];   //[object:object]
    coinData2 = [];     //[object]


    constructor(private fb: FormBuilder, private userService: UserSerivce) {
              this.getAllCoinList();
    }

ngOnInit(){
             this.formGroupBuy=new FormGroup({
                 buy_amount:new FormControl('',Validators.compose([Validators.required,Validators.min(1)])),
                 buy_price:new FormControl('',Validators.compose([Validators.required,Validators.min(1)]))
             });
            this.formGroupBuy.controls['buy_amount'].setValue(10);
            this.reactiveForm=this.fb.group({
                //sell_amount:['',Validators.required],
                sell_amount:['',Validators.compose([Validators.required,Validators.min(1)])],
                sell_price:['',Validators.compose([Validators.required,Validators.min(1)])]
             });

}

getAllCoinList(){
   // this.userService.getAllCoinData().subscribe(data=>{
    this.refreshInterval.subscribe(data=>{
        //console.log(data);
        let str_data=data;
        let str_to_json=JSON.parse(str_data['allCoinData'])
        this.coinData=str_to_json['data'];
        let i=0;
        console.log(this.coinData);
        for(let key in this.coinData){

            this.coinData2[i]=this.coinData[key];
            i++;
            //console.log(this.coinData[key]);
        }
        console.log(this.coinData2[1]);
    });
}


private refreshInterval: Observable<string> = timer(0, 1000)
.pipe(
  // This kills the request if the user closes the component
  // switchMap cancels the last request, if no response have been received since last tick
  switchMap(() => this.userService.getAllCoinData()),
  // catchError handles http throws
  catchError(error => of('Error'))
);






    submitSellForm(){
        console.log(this.reactiveForm);
        //this.buy_amount=data.value;
    }
    submitBuyForm(data){
        console.log(data);

    }

    showError(data){
    console.log(data);
    this.buy_amount=data.value;
    }


}
