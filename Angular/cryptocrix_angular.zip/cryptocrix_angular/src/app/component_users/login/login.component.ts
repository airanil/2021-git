import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserSerivce } from '../../services/user_service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';


@Component({
  templateUrl: './login.component.html',
  providers: [UserSerivce],
  styleUrls: ['./login.component.css']

})
export class LoginComponent implements OnInit {
  result: any;
  formGroupLogin: FormGroup;
  username: string;
  login_error_msg: string;
  show_login_error: boolean;

  constructor(private userService: UserSerivce, private router: Router, private fb: FormBuilder) {
  }

  ngOnInit() {
    this.formGroupLogin = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });

  }
  showError(data) {
    console.log(data);
    }

  userLogin(loginForm) {
    this.formGroupLogin.reset();

    this.login_error_msg = 'please wait...';
    this.userService.login(loginForm).subscribe(data => {
      this.result = data;
      // -----
      // console.log(this.result['data']);
      // let user_json=JSON.parse(this.result['userData']);
      if (this.result['userData']['id'] === 0) {
        this.formGroupLogin.reset();
        this.show_login_error = true;
        this.login_error_msg = 'Invalid username and password';
      } else {
        localStorage.setItem('username', this.result['userData']['username']);
        // console.log(this.result['userData']);
        // console.log(localStorage.getItem('username'));
        // localStorage.setItem("username","");//clear session
        this.router.navigate(['/dashboard']);
      }
      // ------
    });
  }

}// class
