import { Component } from '@angular/core';


@Component({
  selector: 'app-root',    
  templateUrl: './app.component.html',
 // styleUrls: ['../assets/css/main.css','../assets/css/main.css'] 
})
export class AppComponent {
  title = 'landing page';
}
