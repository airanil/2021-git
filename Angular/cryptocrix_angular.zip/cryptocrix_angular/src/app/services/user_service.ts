import {Injectable} from '@angular/core';
import {HttpClient,HttpResponse,HttpHeaders, HttpErrorResponse} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { I_Users } from '../interfaces/I_users';
import { retry, catchError } from 'rxjs/operators';

@Injectable()
export class UserSerivce{

    headers:HttpHeaders;
    options={
        headers:({
          'content-type':'aplication/json'  
        })
    }
    constructor(private http_client:HttpClient){}

    getUserList():Observable<I_Users[]>{
        return this.http_client.get<I_Users[]>('http://localhost:8080/Demo_one/check')
        .pipe(            
            catchError(this.handleError)
        );
    }

    login(loginFrom){
        
        return this.http_client.get<string>('http://localhost:8080/Cryptocryix/getUser/'+loginFrom['username']+'/'+loginFrom['password'])
        .pipe(catchError(this.handleError));
       // return this.http_client.post<string>('http://localhost:8080/Cryptocryix/addUser',loginFrom,this.options);
    }

    newUserEntry(RegForm){
        return this.http_client.post<string>('http://localhost:8080/Cryptocryix/addUser',RegForm,this.options)
        .pipe(catchError(this.handleError));
    }

    getAllCoinData():Observable<string>{
        return this.http_client.get<string>('http://localhost:8080/Cryptocryix/getAllCoinData')
        .pipe(
            retry(3),//try three time if error
            catchError(this.handleError)
            );
    }

    



   private handleError(error:HttpErrorResponse){
        
            if (error.error instanceof ErrorEvent) {
              // A client-side or network error occurred. Handle it accordingly.
              console.error('An error occurred client side:', error.error.message);
            } else {
              // The backend returned an unsuccessful response code.
              // The response body may contain clues as to what went wrong,
              console.error(
                `Backend returned code ${error.status}, ` +
                `body was: ${error.error}`);
            }
            // return an observable with a user-facing error message
            return throwError(
              'Something bad happened; please try again later.');
          };
        
        //return

    


}//class