import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from "@angular/router";
import { Injectable } from "@angular/core";

@Injectable()
export class AuthGuard implements CanActivate{
    username:string;
    constructor(private router:Router){
    }
    canActivate(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):boolean{
        this.username=localStorage.getItem("username");
        
        if(this.username!=""){ 
            return true;
        }
        else{
                this.router.navigate(['/login']);
                return false;
        }    
    }
}