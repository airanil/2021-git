import { NG_VALIDATORS, Validator,  AbstractControl } from '@angular/forms'
import { Directive, Input } from '@angular/core';

@Directive({
    selector:'[appConfirmEqualValidator]',
    providers:[{
        provide:NG_VALIDATORS,
        useExisting:CustomEqualValidator,
        multi:true
    }]
})
export class CustomEqualValidator implements Validator{

    @Input() appConfirmEqualValidator:string
    validate(control:AbstractControl):{[key:string]:any}|null{
        const data=control.parent.get(this.appConfirmEqualValidator);
        if(data && data.value!==control.value){
            return {'notEqual':true};
        }
        else{
            return null;
        }
    }
}