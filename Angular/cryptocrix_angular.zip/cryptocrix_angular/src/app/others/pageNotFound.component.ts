import {Component} from "@angular/core";

@Component({
    template:`<h1>Page not found<h1>`
})
export class PageNotFoundComponenet{

    getData():string{

        return "pageNot Found ";
    }

}