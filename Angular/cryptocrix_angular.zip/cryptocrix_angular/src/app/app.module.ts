
import { NgModule, Component } from '@angular/core';  //ngModule,Component,injectable decorator
import {RouterModule,Routes} from '@angular/router';
import {HttpClientModule} from '@angular/common/http'
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule,ReactiveFormsModule} from '@angular/forms'  

import { AppComponent } from './app.component';
import { LoginComponent} from './component_users/login/login.component';
import {RegistrationComponent} from './component_users/registration/registration.component';
import { PageNotFoundComponenet } from './others/pageNotFound.component';
import {MenuCompoment} from './component_users/menu/menu.component';
import {DashboardComponent} from './component_users/dashboard/dashboard.component'; 
import { from } from 'rxjs';
import { DashboardResuableComponent } from './component_users/ResuableComponent/reusable.component';
import { CustomEqualValidator } from './others/custom_validator';
import { AuthGuard } from './services/auth.guard';

const appRoutes:Routes=[
  {path:'login',component:LoginComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'home',component:AppComponent},
  {path:'dashboard',canActivate:[AuthGuard] ,component:DashboardComponent},
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'**',component:PageNotFoundComponenet}
];

@NgModule({
  declarations: [
      AppComponent,      
      PageNotFoundComponenet,
      LoginComponent,
      RegistrationComponent,
      MenuCompoment,
      DashboardComponent,
      DashboardResuableComponent,
      CustomEqualValidator
  ],
  imports: [
    FormsModule,          //ngSubmit,click,valid
    BrowserModule,        //ngIf/ngFor
    RouterModule.forRoot(appRoutes), //routing
    HttpClientModule,                 // http request    
    ReactiveFormsModule,  //validation
  ],
  bootstrap: [AppComponent],
  providers:[AuthGuard]
})
export class AppModule { }
